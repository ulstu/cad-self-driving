#!/bin/sh

export HTTP_PROXY=http://ftn.proxy:8080
export HTTPS_PROXY=https://ftn.proxy:8080
export FTP_PROXY=ftp://ftn.proxy:8080
export NO_PROXY=localhost,127.0.0.1,::1
